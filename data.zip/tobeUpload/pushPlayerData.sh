
for var in "$@"
do
    echo ${var}    

    ./../search/solr-7.2.1/bin/solr create -c "${var// /}"    
   
    curl -X POST -d '{"add":{ "doc":{"Runs":0,"Mins":0,"4s":0,"6s":0,"SR":12.9992,"Pos":0,"Dismissal":" ","Inns":0 , "Opposition":" ","Ground":"","Start Date":" "}}}' -H "Content-Type: application/json" http://localhost:8983/solr/"${var// /}"/update?commit=true

    ./../search/solr-7.2.1/bin/post -c "${var// /}" /home/akash/Documents/RDream11/backend/data/"$var".csv

done