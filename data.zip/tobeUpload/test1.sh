#!/bin/sh
for var in "$@"
do
    echo ${var}
   #curl "http://localhost:8983/solr/" '${var// /}' "/update?commit=true" -H "Content-type:application/csv" -d 'Runs,Mins,4s,6s,SR,Pos,Dismissal,Inns,Oppostion,Ground,Start_Date,Dismissal_str,Start_Date_str,Opposition_str,Ground_str'
   # ' 0,0,0,0,0.0,0," ",0," "," "," "," "," "," "," "'
    
    
    curl http://localhost:8983/solr/ "${var// /}"
    
done
