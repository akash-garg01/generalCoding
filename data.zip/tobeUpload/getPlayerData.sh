
Rscript GetPlayerId.R "India" "Virat" "Ajinkya Rahane" "Ravichandran Ashwin" "Shikhar Dhawan" "Dinesh Karthik" "Hardik Pandya" "Parthiv Patel" "Cheteshwar Pujara" "Lokesh Rahul" "Murali Vijay" "Rohit Sharma" "Wriddhiman Saha"
