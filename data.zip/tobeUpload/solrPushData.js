const exec = require('child_process').exec;
const fs = require('fs');

var data = fs.readFileSync('players.txt');

console.log(data.toString().trim()); 

var url = 'sh pushPlayerData.sh ' + data.toString().trim();

var yourscript = exec(url,
    function (error, stdout, stderr) {
        console.log(`${stdout}`);
        console.log(`${stderr}`);
        if (error !== null) {
            console.log(`exec error: ${error}`);
        }
    });  