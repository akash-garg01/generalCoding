
var csv = require("fast-csv");


 
csv
 .fromPath("/home/akash/Documents/RDream11/data/p1.csv")
 .on("data", function(data){
     //console.log(data);
     testJSON = JSON.stringify(data); 
     console.log(testJSON);
     console.log(typeof(data));
     
 })
 .on("end", function(err){
     if(err){
         console.log(err);
     }
     console.log("done");
 });