#!/usr/bin/env Rscript

getPlayerCleanData <- function (profile, opposition = "", host = "", dir = "./data", 
                                file = "player001.csv", type = "batting", homeOrAway = c(1, 
                                                                                         2), result = c(1, 2, 4)) 
{
  url <- ""
  suburl1 <- "http://stats.espncricinfo.com/ci/engine/player/"
  suburl2 <- "?class=1;"
  suburl3 <- "template=results;"
  suburl4 <- "view=innings"
  theOpposition <- paste("opposition=", opposition, ";", sep = "")
  hostCountry <- paste("host=", host, ";", sep = "")
  player <- paste(profile, ".html", sep = "")
  
  str1 = str2 = ""
  if (sum(homeOrAway == 1) == 1) {
    str1 = "home_or_away=1;"
  }
  if (sum(homeOrAway == 2) == 1) {
    str2 = "home_or_away=2;"
  }
  HA <- paste(str1, str2, sep = "")
  t <- paste("type=", type, ";", sep = "")
  str1 = str2 = str3 = ""
  if (sum(result == 1) == 1) {
    str1 = "result=1;"
  }
  if (sum(result == 2) == 1) {
    str2 = "result=2;"
  }
  if (sum(result == 4) == 1) {
    str3 = "result=4;"
  }
  result <- paste(str1, str2, str3, sep = "")
  url <- paste(suburl1, player, suburl2, hostCountry, theOpposition, 
               HA, result, suburl3, t, suburl4, sep = "")
  tables = readHTMLTable(url, stringsAsFactors = F)
  t <- tables$"Innings by innings list"
  if (type == "batting") {
    cols <- c(1:9, 11, 12, 13)
  }
  else if (type == "bowling") {
    n <- names(t)
    if (n[2] == "BPO") {
      cols <- c(1:8, 10, 11, 12)
    }
    else {
      cols <- c(1:7, 9, 10, 11)
    }
  }
  
  df <- t[, cols]
  
  pqr <- df$Runs != "DNB"
  batsman <- df[pqr, ]
  c <- batsman$Runs != "TDNB"
  batsman <- batsman[c, ]
  d <- batsman$Runs != "absent"
  batsman <- batsman[d, ]
  batsman$Runs <- as.numeric(gsub("\\*", "", batsman$Runs))
  #".*-", "0", a
  
  batsman$Mins <- as.numeric(gsub(".*-", "0", batsman$Mins))
  batsman$BF <- as.numeric(gsub(".*-", "0", batsman$BF))
  batsman$SR <- as.numeric(gsub(".*-", "0", batsman$SR))
  batsman$Pos <- as.numeric(gsub(".*-", "0", batsman$Pos))
  batsman$Inns <- as.numeric(gsub(".*-", "0", batsman$Inns))
  batsman$'4s' <- as.numeric(gsub(".*-", "0", batsman$'4s'))
  batsman$'6s' <- as.numeric(gsub(".*-", "0", batsman$'6s'))
  
  
  
  c <- complete.cases(batsman)
  batsmanComplete <- batsman[c, ]
  list(val = dim(batsmanComplete), names = names(batsmanComplete), 
       h = head(batsmanComplete))
  
  
  
  dir.create(dir, mode = "0777", showWarnings = FALSE)
  file <- paste(dir, file, sep = "/")
  file.create(file)
   write.csv(batsmanComplete, file = file)
  batsmanComplete
}




find_player_id <- function(searchstring) {
  url <- paste0("http://stats.espncricinfo.com/ci/engine/stats/analysis.html?search=",
                searchstring,";template=analysis")
  url <- gsub(" ", "%20", url)
  raw <- try(xml2::read_html(url), silent = TRUE)
  if ("try-error" %in% class(raw))
    stop("This shouldn't happen")
  # Extract table of names
  tab <- rvest::html_table(raw)[[1]]
  # Make into a table
  tab <- tibble::as_tibble(tab)
  # Check if player exists
  if(unlist(tab[1,1])=="No matching players found")
    stop("No matching players found")
  # Name columns
  colnames(tab) <- c("Name","Country","Played")
  # Remove empty rows
  tab <- tab[tab$Name != "",]
  checkrestrict <- grep("Search restricted", utils::tail(tab,1)[[1]])
  if(length(checkrestrict) == 0L)
    checkrestrict <- FALSE
  if(checkrestrict)
  {
    warning("Only 100 results returned. Please try a more specific search.")
    tab <- utils::head(tab,100)
  }
  # Now to find the ids
  ids <- rvest::html_nodes(raw, 'a')
  ids <- as.character(ids[grep("/ci/engine/player/", ids)])
  ids <- gsub("([a-zA-Z= \\\"/<>]*)","", ids)
  ids <- unlist(lapply(strsplit(ids,".", fixed=TRUE), function(x){x[1]}))
  tab$ID <- as.integer(unique(ids))
  return(tab[,c("ID","Name","Country","Played")])
}


library(stringr)

findPlayerIDBYName <-function(playerName,countryName){
  
  oneVar <- TRUE
  
  playerId <- find_player_id(playerName)
  str1 = playerId[2]
  ids = playerId[1]
  country = playerId[3]
  
  for(str in playerId[2]){
    
  }
  for(it in playerId[1]){
    
  }
  for(cunt in playerId[3]){
    
  }
  
  
  index <- 1
  
  
  if(length(str) > 1){
    oneVar <- FALSE
    
    while(index < length(playerId)){
      cuntVar <- str_detect(cunt[index],regex(countryName, ignore_case = T))
      testVar <- str_detect(str[index],regex(playerName, ignore_case = T))  
      
      if(cuntVar == TRUE && testVar == TRUE){
        str<- str[index]
        it <- it[index]
        break
      }
      index <- index + 1
    }
  }
  
  it
  
}

library(XML)



args <- commandArgs(trailingOnly = TRUE)
argsIndex <- 2

while(argsIndex <= length(args)){
  country <- args[1]
  playerName <- args[argsIndex]
  fileName <- paste(playerName,sep = "",".csv")
  getPlayerCleanData(findPlayerIDBYName(playerName,country),dir="./data",file=fileName)
  argsIndex <- argsIndex + 1
  
}