
var csvtojson =  require('csvtojson'); 
var csvFilePath = "/home/akash/Documents/RDream11/data/p1.csv"; 

csvtojson.fromFile(csvFilePath).on('json',function(jsonObject){
    console.log(jsonObject);
}).on('done',function(err,test){
    if(err){
        console.log(err);
    }
    console.log(test);
}); 